import { useState, useEffect } from 'react';
import { CustomCursor } from './components/CustomCursor';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Pricing } from './components/Pricing';
import { Footer } from './components/Footer';
import { LoginPage } from './components/auth/LoginPage';
import { RegisterForm } from './components/auth/RegisterForm';
import { ContactPage } from './components/contact/ContactPage';
import { DashboardPage } from './components/dashboard/DashboardPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState(window.location.hash || '#home');

  useEffect(() => {
    const handleHashChange = () => {
      setCurrentPage(window.location.hash);
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case '#login':
        return <LoginPage />;
      case '#register':
        return (
          <div className="min-h-screen bg-black flex items-center justify-center p-4">
            <div className="w-full max-w-md">
              <RegisterForm />
            </div>
          </div>
        );
      case '#contato':
        return <ContactPage />;
      case '#dashboard':
        return <DashboardPage />;
      default:
        return (
          <>
            <Header />
            <main>
              <Hero />
              <Features />
              <Pricing />
            </main>
            <Footer />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <CustomCursor />
      {renderPage()}
    </div>
  );
}