import { StatsCard } from './StatsCard';

const statsData = [
  { title: 'Vídeos Criados', value: '12' },
  { title: 'Deep Fotos Criadas', value: '8' },
  { title: 'Vozes Personalizadas', value: '5' },
  { title: 'Créditos Restantes', value: '83' },
];

export const StatsGrid = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statsData.map((stat) => (
        <StatsCard key={stat.title} {...stat} />
      ))}
    </div>
  );
};