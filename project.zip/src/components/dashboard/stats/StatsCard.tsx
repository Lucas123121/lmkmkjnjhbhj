import { motion } from 'framer-motion';

interface StatsCardProps {
  title: string;
  value: string;
}

export const StatsCard = ({ title, value }: StatsCardProps) => {
  return (
    <motion.div
      className="p-6 rounded-2xl bg-gradient-to-b from-purple-900/20 to-transparent border border-purple-500/20"
      whileHover={{ scale: 1.02 }}
    >
      <h3 className="text-gray-400 mb-2">{title}</h3>
      <p className="text-3xl font-bold text-white">{value}</p>
    </motion.div>
  );
};