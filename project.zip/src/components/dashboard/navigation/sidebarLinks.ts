import { Video, Image, Users, Settings } from 'lucide-react';

export const sidebarLinks = [
  { icon: Video, label: 'Meus Vídeos', page: 'videos' },
  { icon: Image, label: 'Deep Fotos', page: 'photos' },
  { icon: Users, label: 'Vozes', page: 'voices' },
  { icon: Settings, label: 'Configurações', page: 'settings' },
];