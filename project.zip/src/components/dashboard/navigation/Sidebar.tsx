import { Brain } from 'lucide-react';
import { SidebarLink } from './SidebarLink';
import { sidebarLinks } from './sidebarLinks';

interface SidebarProps {
  onNavigate: (page: string) => void;
}

export const Sidebar = ({ onNavigate }: SidebarProps) => {
  return (
    <div className="fixed left-0 top-0 h-full w-64 bg-gradient-to-b from-purple-900/40 to-transparent border-r border-purple-500/20">
      <div className="p-6">
        <div className="flex items-center space-x-2 mb-8">
          <Brain className="w-8 h-8 text-purple-500" />
          <span className="text-xl font-bold bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">
            DeepLotus
          </span>
        </div>
        
        <nav className="space-y-4">
          {sidebarLinks.map((link) => (
            <SidebarLink
              key={link.label}
              {...link}
              onClick={() => onNavigate(link.page)}
            />
          ))}
        </nav>
      </div>
    </div>
  );
};