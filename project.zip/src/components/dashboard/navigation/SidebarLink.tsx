import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface SidebarLinkProps {
  icon: LucideIcon;
  label: string;
  page: string;
  onClick: (page: string) => void;
}

export const SidebarLink = ({ icon: Icon, label, page, onClick }: SidebarLinkProps) => {
  return (
    <motion.button
      onClick={() => onClick(page)}
      className="w-full flex items-center space-x-3 text-gray-300 hover:text-purple-400 transition-colors p-2 rounded-lg hover:bg-purple-500/10"
      whileHover={{ x: 5 }}
    >
      <Icon className="w-5 h-5" />
      <span>{label}</span>
    </motion.button>
  );
};