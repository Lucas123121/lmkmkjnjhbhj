import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  action?: {
    label: string;
    icon: LucideIcon;
    onClick: () => void;
  };
}

export const PageHeader = ({ title, action }: PageHeaderProps) => {
  return (
    <div className="flex justify-between items-center">
      <h2 className="text-2xl font-bold text-white">{title}</h2>
      {action && (
        <motion.button
          onClick={action.onClick}
          className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg text-white"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <action.icon className="w-5 h-5" />
          <span>{action.label}</span>
        </motion.button>
      )}
    </div>
  );
};