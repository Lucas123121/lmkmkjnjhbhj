import { useState } from 'react';
import { Sidebar } from './navigation/Sidebar';
import { DashboardHeader } from './header/DashboardHeader';
import { VideosPage } from './pages/videos/VideosPage';
import { PhotosPage } from './pages/photos/PhotosPage';
import { VoicesPage } from './pages/voices/VoicesPage';
import { SettingsPage } from './pages/settings/SettingsPage';

type PageType = 'videos' | 'photos' | 'voices' | 'settings';

export const DashboardPage = () => {
  const [currentPage, setCurrentPage] = useState<PageType>('videos');

  const handleLogout = () => {
    window.location.hash = '#login';
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'videos':
        return <VideosPage />;
      case 'photos':
        return <PhotosPage />;
      case 'voices':
        return <VoicesPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <VideosPage />;
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <Sidebar onNavigate={setCurrentPage} />
      <div className="ml-64 p-8">
        <DashboardHeader onLogout={handleLogout} />
        {renderPage()}
      </div>
    </div>
  );
};