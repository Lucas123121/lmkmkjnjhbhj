import { motion } from 'framer-motion';
import { Download, Trash2, Maximize2 } from 'lucide-react';

interface PhotoCardProps {
  title: string;
  imageUrl: string;
  date: string;
}

export const PhotoCard = ({ title, imageUrl, date }: PhotoCardProps) => {
  return (
    <motion.div 
      className="bg-gradient-to-b from-purple-900/20 to-transparent border border-purple-500/20 rounded-lg overflow-hidden"
      whileHover={{ scale: 1.02 }}
    >
      <div className="relative group">
        <img src={imageUrl} alt={title} className="w-full h-48 object-cover" />
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <button className="text-white hover:text-purple-300">
            <Maximize2 className="w-6 h-6" />
          </button>
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-white font-semibold mb-2">{title}</h3>
        <p className="text-gray-400 text-sm mb-4">{date}</p>
        <div className="flex justify-between">
          <button className="text-purple-400 hover:text-purple-300">
            <Download className="w-5 h-5" />
          </button>
          <button className="text-red-400 hover:text-red-300">
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};