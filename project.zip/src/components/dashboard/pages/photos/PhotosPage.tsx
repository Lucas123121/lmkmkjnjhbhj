import { Upload } from 'lucide-react';
import { PhotoCard } from './PhotoCard';
import { PageHeader } from '../../shared/PageHeader';
import { StatsGrid } from '../../stats/StatsGrid';

const photos = [
  {
    title: 'Retrato Profissional',
    imageUrl: 'https://picsum.photos/400/300',
    date: '2024-03-15'
  },
  {
    title: 'Foto Corporativa',
    imageUrl: 'https://picsum.photos/400/301',
    date: '2024-03-14'
  },
  {
    title: 'Perfil Comercial',
    imageUrl: 'https://picsum.photos/400/302',
    date: '2024-03-13'
  }
];

export const PhotosPage = () => {
  return (
    <div className="space-y-8">
      <StatsGrid />
      
      <div className="space-y-6">
        <PageHeader 
          title="Deep Fotos" 
          action={{
            label: "Nova Foto",
            icon: Upload,
            onClick: () => console.log('Upload photo')
          }}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {photos.map((photo, index) => (
            <PhotoCard key={index} {...photo} />
          ))}
        </div>
      </div>
    </div>
  );
};