import { motion } from 'framer-motion';
import { Play, Download, Trash2 } from 'lucide-react';

interface VideoCardProps {
  title: string;
  thumbnail: string;
  duration: string;
  date: string;
}

export const VideoCard = ({ title, thumbnail, duration, date }: VideoCardProps) => {
  return (
    <motion.div 
      className="bg-gradient-to-b from-purple-900/20 to-transparent border border-purple-500/20 rounded-lg overflow-hidden"
      whileHover={{ scale: 1.02 }}
    >
      <div className="relative">
        <img src={thumbnail} alt={title} className="w-full h-48 object-cover" />
        <span className="absolute bottom-2 right-2 bg-black/60 text-white px-2 py-1 rounded text-sm">
          {duration}
        </span>
      </div>
      <div className="p-4">
        <h3 className="text-white font-semibold mb-2">{title}</h3>
        <p className="text-gray-400 text-sm mb-4">{date}</p>
        <div className="flex justify-between">
          <button className="text-purple-400 hover:text-purple-300">
            <Play className="w-5 h-5" />
          </button>
          <button className="text-purple-400 hover:text-purple-300">
            <Download className="w-5 h-5" />
          </button>
          <button className="text-red-400 hover:text-red-300">
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};