import { Upload } from 'lucide-react';
import { VideoCard } from './VideoCard';
import { PageHeader } from '../../shared/PageHeader';

const videos = [
  {
    title: 'Apresentação Corporativa',
    thumbnail: 'https://picsum.photos/400/300',
    duration: '2:30',
    date: '2024-03-15'
  },
  // Add more sample videos as needed
];

export const VideosPage = () => {
  return (
    <div className="space-y-6">
      <PageHeader 
        title="Meus Vídeos" 
        action={{
          label: "Novo Vídeo",
          icon: Upload,
          onClick: () => console.log('Upload video')
        }}
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {videos.map((video, index) => (
          <VideoCard key={index} {...video} />
        ))}
      </div>
    </div>
  );
};