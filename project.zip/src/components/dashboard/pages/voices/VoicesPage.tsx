import { Mic } from 'lucide-react';
import { VoiceCard } from './VoiceCard';
import { PageHeader } from '../../shared/PageHeader';
import { StatsGrid } from '../../stats/StatsGrid';

const voices = [
  {
    name: 'Voz Corporativa',
    duration: '5:30',
    date: '2024-03-15',
    samples: 12
  },
  {
    name: 'Voz Comercial',
    duration: '3:45',
    date: '2024-03-14',
    samples: 8
  },
  {
    name: 'Voz Narração',
    duration: '4:20',
    date: '2024-03-13',
    samples: 10
  }
];

export const VoicesPage = () => {
  return (
    <div className="space-y-8">
      <StatsGrid />
      
      <div className="space-y-6">
        <PageHeader 
          title="Vozes" 
          action={{
            label: "Nova Voz",
            icon: Mic,
            onClick: () => console.log('Create voice')
          }}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {voices.map((voice, index) => (
            <VoiceCard key={index} {...voice} />
          ))}
        </div>
      </div>
    </div>
  );
};