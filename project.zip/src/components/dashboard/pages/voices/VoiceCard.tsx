import { motion } from 'framer-motion';
import { Play, Download, Trash2, Pencil } from 'lucide-react';

interface VoiceCardProps {
  name: string;
  duration: string;
  date: string;
  samples: number;
}

export const VoiceCard = ({ name, duration, date, samples }: VoiceCardProps) => {
  return (
    <motion.div 
      className="bg-gradient-to-b from-purple-900/20 to-transparent border border-purple-500/20 rounded-lg p-4"
      whileHover={{ scale: 1.02 }}
    >
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-white font-semibold">{name}</h3>
          <p className="text-gray-400 text-sm">{date}</p>
        </div>
        <button className="text-purple-400 hover:text-purple-300">
          <Pencil className="w-4 h-4" />
        </button>
      </div>
      
      <div className="mb-4">
        <div className="text-gray-400 text-sm mb-2">
          <span>{duration}</span>
          <span className="mx-2">•</span>
          <span>{samples} amostras</span>
        </div>
      </div>

      <div className="flex justify-between">
        <button className="text-purple-400 hover:text-purple-300">
          <Play className="w-5 h-5" />
        </button>
        <button className="text-purple-400 hover:text-purple-300">
          <Download className="w-5 h-5" />
        </button>
        <button className="text-red-400 hover:text-red-300">
          <Trash2 className="w-5 h-5" />
        </button>
      </div>
    </motion.div>
  );
};