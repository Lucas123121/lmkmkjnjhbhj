import { PageHeader } from '../../shared/PageHeader';
import { StatsGrid } from '../../stats/StatsGrid';

export const SettingsPage = () => {
  return (
    <div className="space-y-8">
      <StatsGrid />
      
      <div className="space-y-6">
        <PageHeader title="Configurações" />
        
        <div className="grid gap-6">
          <div className="bg-gradient-to-b from-purple-900/20 to-transparent border border-purple-500/20 rounded-lg p-6">
            <h3 className="text-lg font-medium text-white mb-4">Preferências</h3>
            <div className="space-y-4">
              <div>
                <label className="flex items-center space-x-3">
                  <input type="checkbox" className="form-checkbox text-purple-500" />
                  <span className="text-gray-300">Ativar notificações</span>
                </label>
              </div>
              <div>
                <label className="flex items-center space-x-3">
                  <input type="checkbox" className="form-checkbox text-purple-500" />
                  <span className="text-gray-300">Modo de alta qualidade</span>
                </label>
              </div>
              <div>
                <label className="flex items-center space-x-3">
                  <input type="checkbox" className="form-checkbox text-purple-500" />
                  <span className="text-gray-300">Salvar histórico de criações</span>
                </label>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-b from-purple-900/20 to-transparent border border-purple-500/20 rounded-lg p-6">
            <h3 className="text-lg font-medium text-white mb-4">API</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Chave da API
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    className="flex-1 bg-purple-900/20 border border-purple-500/30 rounded-lg py-2 px-3 text-white"
                    value="sk-****************************************"
                    readOnly
                  />
                  <button className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
                    Copiar
                  </button>
                </div>
              </div>
              <button className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
                Gerar Nova Chave
              </button>
            </div>
          </div>

          <div className="bg-gradient-to-b from-purple-900/20 to-transparent border border-purple-500/20 rounded-lg p-6">
            <h3 className="text-lg font-medium text-white mb-4">Conta</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value="teste@teste.com"
                  className="w-full bg-purple-900/20 border border-purple-500/30 rounded-lg py-2 px-3 text-white"
                  readOnly
                />
              </div>
              <button className="px-4 py-2 border border-red-500 text-red-400 rounded-lg hover:bg-red-500/10 transition-colors">
                Excluir Conta
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};