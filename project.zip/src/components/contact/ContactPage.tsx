import { motion } from 'framer-motion';
import { ContactForm } from './ContactForm';

export const ContactPage = () => {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4" id="contato">
      <div className="absolute inset-0">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 -left-4 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-blob" />
          <div className="absolute top-0 -right-4 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-2000" />
          <div className="absolute -bottom-8 left-20 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-4000" />
        </div>
      </div>
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md p-8 rounded-2xl bg-gradient-to-b from-purple-900/40 to-transparent border border-purple-500/20 relative z-10"
      >
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h2 className="text-3xl font-bold text-white mb-2">
            Entre em Contato
          </h2>
          <p className="text-gray-400">
            Estamos aqui para ajudar. Envie sua mensagem!
          </p>
        </motion.div>
        <ContactForm />
      </motion.div>
    </div>
  );
};