import { useState } from 'react';
import { motion } from 'framer-motion';

export const Navigation = () => {
  const [currentPage, setCurrentPage] = useState(window.location.hash || '#home');

  const handleNavigation = (page: string) => {
    setCurrentPage(page);
    window.location.hash = page;
  };

  return (
    <nav className="hidden md:flex items-center space-x-8">
      {[
        { label: 'Home', hash: '#home' },
        { label: 'Funcionalidades', hash: '#funcionalidades' },
        { label: 'Preços', hash: '#precos' },
        { label: 'Login', hash: '#login' },
        { label: 'Contato', hash: '#contato' }
      ].map(({ label, hash }) => (
        <motion.a
          key={hash}
          href={hash}
          onClick={() => handleNavigation(hash)}
          className={`text-gray-300 hover:text-purple-400 transition-colors ${
            currentPage === hash ? 'text-purple-400' : ''
          }`}
          whileHover={{ scale: 1.1 }}
        >
          {label}
        </motion.a>
      ))}
      <motion.button
        onClick={() => handleNavigation('#register')}
        className="px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full text-white font-medium"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        Teste Agora
      </motion.button>
    </nav>
  );
};