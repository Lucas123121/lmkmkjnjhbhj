import { motion } from 'framer-motion';
import { Video, Mic, Link, Shield } from 'lucide-react';

const features = [
  {
    icon: Video,
    title: 'Vídeos Hiper-realistas',
    description: 'Crie conteúdo visual impressionante com nossa tecnologia de deep fake de última geração.'
  },
  {
    icon: Mic,
    title: 'Personalização de Vozes',
    description: 'Sintetize vozes naturais e personalizadas para seus projetos com precisão incomparável.'
  },
  {
    icon: Link,
    title: 'Integração via API',
    description: 'Conecte nossa tecnologia aos seus sistemas existentes com nossa API robusta e flexível.'
  },
  {
    icon: Shield,
    title: 'Ética e Segurança',
    description: 'Prioridade máxima em segurança e uso ético, com proteções avançadas contra uso indevido.'
  }
];

export const Features = () => {
  return (
    <section className="py-20 bg-black" id="funcionalidades">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Recursos <span className="bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">Revolucionários</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Descubra as ferramentas avançadas que tornam o DeepLotus a escolha ideal para suas necessidades de deep fake.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="p-6 rounded-2xl bg-gradient-to-b from-purple-900/20 to-transparent border border-purple-500/20 hover:border-purple-500/40 transition-colors"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <feature.icon className="w-12 h-12 text-purple-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};