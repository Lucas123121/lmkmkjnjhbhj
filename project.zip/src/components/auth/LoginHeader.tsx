import { motion } from 'framer-motion';
import { Brain } from 'lucide-react';

export const LoginHeader = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center mb-8"
    >
      <div className="flex items-center justify-center mb-6">
        <Brain className="w-12 h-12 text-purple-500" />
      </div>
      <h2 className="text-3xl font-bold text-white mb-2">
        Bem-vindo de volta
      </h2>
      <p className="text-gray-400">
        Entre com suas credenciais para acessar sua conta
      </p>
    </motion.div>
  );
};