import { PricingHeader } from './pricing/PricingHeader';
import { PricingCard } from './pricing/PricingCard';
import { pricingPlans } from './pricing/pricingData';

export const Pricing = () => {
  return (
    <section className="py-20 bg-black" id="precos">
      <div className="container mx-auto px-4">
        <PricingHeader />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingPlans.map((plan, index) => (
            <PricingCard key={index} plan={plan} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};