import { motion } from 'framer-motion';

export const PricingHeader = () => {
  return (
    <motion.div 
      className="text-center mb-16"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
    >
      <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
        Planos e <span className="bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">Preços</span>
      </h2>
      <p className="text-gray-400 max-w-2xl mx-auto">
        Escolha o plano ideal para suas necessidades e comece a transformar sua criatividade hoje mesmo.
      </p>
    </motion.div>
  );
};