import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

interface PricingPlan {
  name: string;
  price: string;
  features: string[];
  popular?: boolean;
}

interface PricingCardProps {
  plan: PricingPlan;
  index: number;
}

export const PricingCard = ({ plan, index }: PricingCardProps) => {
  const cardClass = plan.popular
    ? 'bg-gradient-to-b from-purple-900/40 to-transparent border-2 border-purple-500'
    : 'bg-gradient-to-b from-purple-900/20 to-transparent border border-purple-500/20';

  return (
    <motion.div
      className={`p-8 rounded-2xl ${cardClass}`}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
    >
      {plan.popular && (
        <span className="px-3 py-1 text-sm bg-gradient-to-r from-purple-500 to-blue-500 rounded-full text-white inline-block mb-4">
          Mais Popular
        </span>
      )}
      <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
      <div className="mb-6">
        <span className="text-4xl font-bold text-white">${plan.price}</span>
        {typeof plan.price === 'number' && <span className="text-gray-400">/mês</span>}
      </div>
      <ul className="space-y-4 mb-8">
        {plan.features.map((feature, featureIndex) => (
          <li key={featureIndex} className="flex items-center text-gray-300">
            <Check className="w-5 h-5 text-purple-400 mr-2" />
            {feature}
          </li>
        ))}
      </ul>
      <button 
        className={`w-full py-3 rounded-full font-medium transition-transform hover:scale-105 ${
          plan.popular
            ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white'
            : 'border border-purple-500 text-white'
        }`}
      >
        Assinar Agora
      </button>
    </motion.div>
  );
};