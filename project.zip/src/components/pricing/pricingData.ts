export const pricingPlans = [
  {
    name: 'Básico',
    price: '49',
    features: [
      'Até 10 vídeos por mês',
      'Personalização básica de voz',
      'API com limite de requisições',
      'Suporte por email'
    ]
  },
  {
    name: 'Pro',
    price: '99',
    popular: true,
    features: [
      'Até 50 vídeos por mês',
      'Personalização avançada de voz',
      'API sem limite de requisições',
      'Suporte prioritário 24/7',
      'Recursos de segurança avançados'
    ]
  },
  {
    name: 'Empresarial',
    price: 'Personalizado',
    features: [
      'Volume ilimitado de vídeos',
      'Personalização total',
      'API dedicada',
      'Gerente de conta exclusivo',
      'SLA garantido',
      'Treinamento da equipe'
    ]
  }
];